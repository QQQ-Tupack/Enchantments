package me.enchantments.mechanics;

import me.enchantments.main.Enchantments;
import me.enchantments.utils.EnchantMeta;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/**
 * Зачарування на броню вовка: захист власника, підбір предметів, нюхання скринь, погладжування, /pet-телепорт.
 * Все залежить від рівня зачарування на wolf_armor, вдягненому на вовка.
 */
public final class WolfCompanionMechanic extends Mechanic implements CommandExecutor {

    private final boolean protectFromOwnerDamage, protectFromOwnerProjectiles, protectSuffocation, protectNamedTarget;
    private final boolean fetchEnabled, sniffEnabled, pettingEnabled;
    private final double fetchRadius, sniffRadius;
    private final int itemAgeThreshold, sniffGlowTicks;
    private final List<Material> fetchExcluded;
    private final String command;

    public WolfCompanionMechanic(EnchantMeta meta, ConfigurationSection p) {
        super(meta);
        protectFromOwnerDamage = p.getBoolean("protect_from_owner_damage", true);
        protectFromOwnerProjectiles = p.getBoolean("protect_from_owner_projectiles", true);
        protectSuffocation = p.getBoolean("protect_suffocation", true);
        protectNamedTarget = p.getBoolean("protect_named_target", true);
        fetchEnabled = p.getBoolean("fetch.enabled", true);
        fetchRadius = p.getDouble("fetch.radius", 50);
        itemAgeThreshold = p.getInt("fetch.item_age_threshold", 200);
        fetchExcluded = p.getStringList("fetch.excluded_items").stream().map(Material::matchMaterial).filter(Objects::nonNull).toList();
        sniffEnabled = p.getBoolean("sniff.enabled", true);
        sniffRadius = p.getDouble("sniff.radius", 50);
        sniffGlowTicks = p.getInt("sniff.glow_ticks", 200);
        pettingEnabled = p.getBoolean("petting.enabled", true);
        command = p.getString("command", "pet");

        if (fetchEnabled) new WolfItemFetcher().runTaskTimer(Enchantments.getInstance(), 0L, 100L);
    }

    @Override
    public String commandName() { return command; }

    private ItemStack armor(Wolf wolf) {
        return wolf.getEquipment() == null ? null : wolf.getEquipment().getItem(EquipmentSlot.BODY);
    }

    private boolean guarded(Wolf wolf) {
        return wolf.isTamed() && levelOf(armor(wolf)) > 0;
    }

    // ── захист ──────────────────────────────────────────────────────────────

    @EventHandler
    public void onWolfAttack(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Wolf wolf) || !(e.getDamager() instanceof Player player)) return;
        if (protectFromOwnerDamage && guarded(wolf) && player.equals(wolf.getOwner())) e.setCancelled(true);
    }

    @EventHandler
    public void onWolfTarget(EntityTargetEvent e) {
        if (!(e.getEntity() instanceof Wolf wolf) || !guarded(wolf) || !protectNamedTarget) return;
        if (e.getTarget() != null && e.getTarget().customName() != null) e.setCancelled(true);
    }

    @EventHandler
    public void onWolfDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Wolf wolf) || !guarded(wolf)) return;

        if (protectFromOwnerProjectiles && e.getCause() == EntityDamageEvent.DamageCause.PROJECTILE
                && e instanceof EntityDamageByEntityEvent byEntity
                && byEntity.getDamager() instanceof Projectile proj
                && proj.getShooter() instanceof Player shooter && shooter.equals(wolf.getOwner())) {
            e.setCancelled(true);
        }
        if (protectSuffocation && e.getCause() == EntityDamageEvent.DamageCause.SUFFOCATION) e.setCancelled(true);
    }

    @EventHandler
    public void onChangeWorld(PlayerChangedWorldEvent e) {
        Player player = e.getPlayer();
        e.getFrom().getEntitiesByClass(Wolf.class).stream()
                .filter(w -> w.isTamed() && player.equals(w.getOwner()) && guarded(w) && !w.isSitting())
                .forEach(w -> w.teleport(player.getLocation()));
    }

    // ── погладжування / нюхання ────────────────────────────────────────────

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e) {
        if (!(e.getRightClicked() instanceof Wolf wolf) || !guarded(wolf)) return;
        Player player = e.getPlayer();
        if (!wolf.isTamed() || !wolf.getOwner().equals(player)) return;

        ItemStack held = player.getInventory().getItemInMainHand();
        boolean emptyHand = held.getType() == Material.AIR;

        if (pettingEnabled && player.isSneaking() && emptyHand) {
            player.sendActionBar(Component.text("Ви лагідно погладили свого вовка!", NamedTextColor.LIGHT_PURPLE));
            wolf.getWorld().playSound(wolf.getLocation(), "entity.wolf.whine", 1.0f, 1.0f);
            wolf.getWorld().spawnParticle(Particle.HEART, wolf.getLocation().add(0, 0.5, 0), 10, 0.3, 0.3, 0.3, 0.02);
            e.setCancelled(true);
            return;
        }
        if (sniffEnabled && player.isSneaking() && !emptyHand) {
            e.setCancelled(true);
            sniff(player, wolf, held.getType());
        }
    }

    private void sniff(Player player, Wolf wolf, Material target) {
        World world = wolf.getWorld();
        world.playSound(wolf.getLocation(), "entity.sniffer.sniffing", 1.0f, 1.4f);
        Location center = player.getLocation();
        List<org.bukkit.entity.Entity> markers = new ArrayList<>();

        for (org.bukkit.Chunk chunk : world.getLoadedChunks()) {
            if (Math.abs((chunk.getX() << 4) + 8 - center.getBlockX()) > sniffRadius + 16) continue;
            if (Math.abs((chunk.getZ() << 4) + 8 - center.getBlockZ()) > sniffRadius + 16) continue;

            for (BlockState state : chunk.getTileEntities()) {
                if (!(state instanceof Container container) || state.getLocation().distance(center) > sniffRadius) continue;
                boolean hasItem = Arrays.stream(container.getInventory().getContents())
                        .anyMatch(stack -> stack != null && stack.getType() == target);
                if (!hasItem) continue;

                BlockDisplay display = (BlockDisplay) world.spawnEntity(state.getLocation(), EntityType.BLOCK_DISPLAY);
                display.setBlock(state.getBlockData());
                display.setGlowing(true);
                display.setInvulnerable(true);
                markers.add(display);
            }
        }

        if (markers.isEmpty()) {
            player.sendActionBar(Component.text("Вовк нічого не знайшов поблизу...", NamedTextColor.GRAY));
            return;
        }
        player.sendActionBar(Component.text("Вовк учув " + markers.size() + " скриню(ь) з цим предметом!", NamedTextColor.YELLOW));
        new BukkitRunnable() {
            @Override public void run() { markers.forEach(org.bukkit.entity.Entity::remove); }
        }.runTaskLater(Enchantments.getInstance(), sniffGlowTicks);
    }

    // ── команда телепорту ──────────────────────────────────────────────────

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        boolean teleported = player.getWorld().getEntitiesByClass(Wolf.class).stream()
                .filter(w -> w.isTamed() && player.equals(w.getOwner()) && guarded(w) && !w.isSitting())
                .peek(w -> w.teleport(player.getLocation()))
                .count() > 0;
        player.sendMessage(teleported
                ? Component.text("Вовки прикликані!", NamedTextColor.GREEN)
                : Component.text("Немає прикликаних вовків із зачарованою бронею.", NamedTextColor.RED));
        return true;
    }

    // ── підбір предметів ───────────────────────────────────────────────────

    private final class WolfItemFetcher extends BukkitRunnable {
        @Override
        public void run() {
            Bukkit.getOnlinePlayers().forEach(player ->
                    player.getWorld().getEntitiesByClass(Wolf.class).stream()
                            .filter(w -> w.isTamed() && player.equals(w.getOwner()) && guarded(w) && !w.isSitting() && !w.isAngry())
                            .forEach(wolf -> fetchNearest(player, wolf)));
        }

        private void fetchNearest(Player player, Wolf wolf) {
            wolf.getWorld().getNearbyEntities(wolf.getLocation(), fetchRadius, fetchRadius, fetchRadius).stream()
                    .filter(this::isValidItem)
                    .filter(entity -> entity.getLocation().distance(player.getLocation()) >= 5)
                    .min(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(wolf.getLocation())))
                    .ifPresent(entity -> {
                        wolf.teleport(entity.getLocation());
                        wolf.setAI(false);
                        new BukkitRunnable() {
                            @Override public void run() {
                                wolf.teleport(player.getLocation().add(0, 0, 1));
                                if (entity instanceof Arrow arrow) {
                                    player.getInventory().addItem(arrow.getItemStack());
                                    entity.remove();
                                } else {
                                    entity.teleport(player.getLocation());
                                }
                                wolf.setAI(true);
                            }
                        }.runTaskLater(Enchantments.getInstance(), 20L);
                    });
        }

        private boolean isValidItem(org.bukkit.entity.Entity entity) {
            if (entity.getTicksLived() < itemAgeThreshold) return false;
            if (entity instanceof Item item) return !fetchExcluded.contains(item.getItemStack().getType());
            return entity instanceof Arrow || entity instanceof ExperienceOrb;
        }
    }
}
